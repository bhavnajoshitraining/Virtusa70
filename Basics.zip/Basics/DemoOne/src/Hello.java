public class Hello {
//my first class on java
	public static void main(String[] args) {
		/*i am
		 * multi
		 * line 
		 * comment*/
		// TODO Auto-generated method stub
		int a,b,c;
	
		b=12;
		a=10;
		c=a+b;
//		System.out.println("Hello World!!!!"+a);
//		System.out.println(c);
		
		//Widening
		int myInt = 10;
		double myDouble = myInt;
		
//		System.out.println("integer is"+myInt);
//		System.out.println("Double is"+myDouble);
		
		//Narrowing 
		long l = 2l;
		int tt = (int)l;
		System.out.println("Long is"+l);
		System.out.println("Int is"+tt);
		
	}
}
