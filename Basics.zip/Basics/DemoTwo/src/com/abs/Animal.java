package com.abs;

abstract class Animal {
	public abstract void animalSound();
	public void eat() {
		System.out.println("I am eating!!!");
	}
}
