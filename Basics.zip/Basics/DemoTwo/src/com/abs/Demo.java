package com.abs;

public class Demo {

	public static void main(String[] args) {
		Dog moti = new Dog();
		moti.animalSound();
		moti.eat();

	}

}
