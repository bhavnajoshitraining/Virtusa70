package com.abs;

public class Dog extends Animal {

	@Override
	public void animalSound() {
		System.out.println("Bho Bho");
	}

}
