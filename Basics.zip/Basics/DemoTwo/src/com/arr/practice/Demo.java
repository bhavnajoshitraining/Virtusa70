package com.arr.practice;

public class Demo {

	public static void main(String[] args) {
	
		int[][]test = {
				{1,2,3},
				{4,5,6},
				{9}
		};
		
		for(int i=0;i<test.length;++i) {
			for(int j=0;j<test[i].length;++j) {
				System.out.print(test[i][j]);
			}
			System.out.println(" ");
		}
		

		
//		int[][][] test = {
//				{
//					{1,2,3},
//					{4,5,6}
//				},
//				{
//					{11,12,13},
//					{14,15,16}
//				}
//		};
//		
//		for(int[][] a2d:test) {
//			for(int[] a1d:a2d) {
//				for(int a:a1d) {
//					System.out.print(a);
//				}
//				System.out.println(" ");
//			}
//			System.out.println(" ");
//		}
//		
		//int[][] id = new int[3][4];
//		int[][][] id ={ {{1,2,3},{4,5,6}}};
		//System.out.println(id.length);
//		for(int i =0;i<id.length;i++) {
//			for(int j=0;j<id[i].length;j++) {
//				id[i][j] = i*j;
//			}
//		}
		
//		for(int i =0;i<id.length;i++) {
//			for(int j=0;j<id[i].length;j++) {
//				System.out.println(id[i][j]);
//			}
//		}		
		//way 1
//		int[] id = new int[5];
//		String[] names = new String[4];
//		id[0] =6;
//		id[1] =7;
//		id[2] =8;
//		id[3] =9;
//		id[4] =10;
//		names[0]="nisha";
//		names[1]="isha";
//		names[2]="disha";
//		names[3]="tisha";
//		
//		
//		//way2
//		int[] id2 = {1,2,3,4,5};
//		String[] names2 = {"anu","bhanu","sonu","manu"};
//		
//		System.out.println(names2[1]);
//		System.out.println(names[3]);
//		
//		
//		System.out.println(names.length);
//		
//		
//		for(int i =0;i<names.length;i++) {
//			System.out.println(names[i]);
//		}
//		
//		
//		for(String a:names) {
//			System.out.println(a);
//		}
	
		
		//print sum of array elements
		//avg of array elements
//		int sum =0;
//		for(int b:id) {
//			sum+=b;
//		}
//		
//		System.out.println("sum is "+sum);
//		
//		
//		int avg =sum/id.length;
//		
//		System.out.println("avg is "+avg);	
		
	}
}
