package com.demo;

public class Animal {
	int id;
	String name;
	int age;
	
	void PrintDetails(Animal a) {
		System.out.println("I am "+a.name+" and my Details are:- \n id "+a.id+" "+"\n name:- "+a.name+"\n age "+a.age);
	}
	
	public Animal() {
		id=10;
		name="cons";
		age=11;
	}
	
	public Animal(int c,String a,int b) {
		id=c;
		name=a;
		age=b;
	}
}
