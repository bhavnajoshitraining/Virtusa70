package com.demo;

public class Two {
	public static void main(String[] args) {
		Animal cow=new Animal();
		Animal dog = new Animal();
		Animal cat = new Animal(3,"Jerry",10);
//		cow.id=1;
//		cow.age=10;
//		cow.name="Gauri";
		cow.PrintDetails(cow);
		dog.id=2;
		dog.name="moti";
		dog.age=5;
		dog.PrintDetails(dog);
		cat.PrintDetails(cat);
	}
}
