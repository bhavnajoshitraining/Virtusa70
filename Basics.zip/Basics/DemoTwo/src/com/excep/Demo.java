package com.excep;

import java.util.Scanner;

public class Demo {

//	static void myfun() throws IllegalAccessException {
//		System.out.println("inside myfun!!");
//		throw new IllegalAccessException("demo");
//	}
	
//	static void checkEligibility(int age) throws ArithmeticException {
//		throw new ArithmeticException("Your age is not fitting our criteria!!!");
//	}
	
	
//	public static void divideByZero() {
//		throw new ArithmeticException("Trying to divide by zero 000000!!!!");
//	}
	public static void main(String[] args) throws InterruptedException{
//		try {
//			int divideByZero = 10/0;
//			//Normal code
//		}catch(Exception e) {
//			System.out.println(e.getMessage());
//			e.printStackTrace();
//		}
		
		
//		try {
//			int divideByZero = 10/0;
//			//Normal code
//		}catch(ArithmeticException e) {
//			System.out.println(e.getMessage());
//			//e.printStackTrace();
//		}
		
		
//		Scanner scnr = new Scanner(System.in);
//		
//		try {
//			System.out.println("Enter a number:- ");
//			int n = Integer.parseInt(scnr.nextLine());
//			int b = 10/n;
//			if(n!=0) {
//				System.out.println("the number you entered is not 0"+b);
//			}
//		}catch(ArithmeticException e) {
//			System.out.println("Exception occured !!!!");
//		}catch(Exception e) {
//			System.out.println("Default Exception block!!!!!");
//		}
		
		
//		Scanner scnr = new Scanner(System.in);
//		
//		try {
//			System.out.println("Enter a number:- ");
//			int n = Integer.parseInt(scnr.nextLine());
//			int b = 10/n;
//			if(n!=0) {
//				System.out.println("the number you entered is not 0"+b);
//			}
//		}catch(ArithmeticException e) {
//			System.out.println("ArithmeticException occured !!!!"+e.getMessage());
//		}
//		catch(NumberFormatException e) {
//			System.out.println("NumberFormatException occured !!!!"+e.getMessage());
//		}
//		catch(Exception e) {
//			System.out.println("Exception occured !!!!"+e.getMessage());
//		}finally {
//			System.out.println("I reached to finally block now!!!!!!!!!!");
//		}
//		try {
//			divideByZero();
//		} catch (Exception e) {
//			System.out.println("exception"+e.getMessage());
//		}
		
		//checkEligibility(10);
		
//		Thread.sleep(100000);
//		System.out.println("Hello Virtusa!!!!");
		
//		try {
//			myfun();
//		} catch (IllegalAccessException e) {
//			System.out.println("catchblock");
//		}
	}
}
