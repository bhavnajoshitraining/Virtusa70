package com.hyb;

public class A extends C {
	public void display() {
		System.out.println("from class A");
	}
}
