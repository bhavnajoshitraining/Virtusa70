package com.hyb;

public class B extends C {
	public void display() {
		System.out.println("from class B");
	}
}
