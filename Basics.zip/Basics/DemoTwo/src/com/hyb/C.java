package com.hyb;

public class C {

	public void display() {
		System.out.println("from class C");
	}
}
