package com.hyb;

public class D extends A {
	public void display() {
		System.out.println("from class D");
	}
}
