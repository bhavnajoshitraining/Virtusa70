package com.inheritancedemo;

public class Animal {
	String name;
	public void eat() {
		System.out.println("I am eating!!!!");
	}
}
