package com.inheritancedemo;

public class Bus extends Vehicle {
	public void run() {
		System.out.println("drrrrrrrrrrrrrrrrrrr");
	}
	public void applyBreak() {
		System.out.println("Stop it!!!");
	}	
}
