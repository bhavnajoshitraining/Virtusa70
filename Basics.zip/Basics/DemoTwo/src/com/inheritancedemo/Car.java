package com.inheritancedemo;

public class Car extends Vehicle {
	public void race() {
		run();
	}
	
	public void result() {
		applyBreak();
	}
}
