package com.inheritancedemo;

public class Demo extends Animal{

	public static void main(String[] args) {
		
		Bus b = new Bus();
		b.applyBreak();
		b.run();
		
		
//		Demo d = new Demo();
//		Dog m = new Dog();
//		m.eat();
//		d.eat();
//		Dog d = new Dog();
//		d.name="monty";
//		d.display();
		
		
		
//		Car sunny = new Car();
//		
//		sunny.run();
//		sunny.race();
//		sunny.applyBreak();
//		sunny.result();
	}

}
