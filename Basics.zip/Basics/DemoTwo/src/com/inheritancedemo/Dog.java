package com.inheritancedemo;

public class Dog extends Demo {
	public void display() {
		System.out.println("My Name is "+name);
	}
}
