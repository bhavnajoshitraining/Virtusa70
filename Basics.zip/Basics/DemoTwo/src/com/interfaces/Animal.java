package com.interfaces;

public interface Animal {
	public void sound();
	public void sleep();
	public void run();
}
