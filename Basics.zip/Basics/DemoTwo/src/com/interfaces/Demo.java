package com.interfaces;

public class Demo {
	final int a = 10;
	public static void main(String[] args) {
		
//		Demo d = new Demo();
//		d.a=11;
//		System.out.println(d.a);
		// TODO Auto-generated method stub
//		Pig p = new Pig();
//		p.sound();
//		p.sleep();
//		p.run();
		
		
//		Multi m = new Multi();
//		m.nosleep();
//		m.soundsleep();
	}

}
