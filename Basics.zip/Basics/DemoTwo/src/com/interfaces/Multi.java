package com.interfaces;

public class Multi implements Animal, Sleeping {

	@Override
	public void soundsleep() {
		System.out.println("Soundsleep!!!!");

	}

	@Override
	public void nosleep() {
		System.out.println("nosleep!!!!");
	}

	@Override
	public void sound() {
		System.out.println("sound!!!!");
	}

	@Override
	public void sleep() {
		System.out.println("sleep!!!!");
	}

	@Override
	public void run() {
		System.out.println("run!!!!");
	}

}
