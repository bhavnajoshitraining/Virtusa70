package com.interfaces;

public interface Sleeping {
	public void soundsleep();
	public void nosleep();
}
