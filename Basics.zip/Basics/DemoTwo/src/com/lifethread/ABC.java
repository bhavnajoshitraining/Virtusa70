package com.lifethread;

public class ABC implements Runnable {

	@Override
	public void run() {
		try {
			Thread.sleep(100);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("State of thread t1 while it invoked join on thread 2 "+ ThreadState.t1.getState() );
		
		try {
			Thread.sleep(200);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("State of thread t1 "+ ThreadState.t1.getState() );
	}
}
