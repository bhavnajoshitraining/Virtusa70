package com.lifethread;

public class ThreadState implements Runnable {

	public static Thread t1;
	public static ThreadState obj;

	public static void main(String[] args) {
		obj = new ThreadState();
		t1 = new Thread(obj);
		System.out.println("The State of Thread t1 "+t1.getState());
		t1.start();
		
		System.out.println("The State of Thread t1 after invoking start "+t1.getState());
		
	}
	
	@Override
	public void run() {
		ABC myObj = new ABC();
		Thread t2 = new Thread(myObj);
		
		System.out.println("The state of t2 is "+t2.getState());
		t2.start();

		System.out.println("The state of t2 is "+t2.getState());
		
		try {
			Thread.sleep(250);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("State pf t2 after invoking sleep "+t2.getState());
		System.out.println("State pf t1 "+t1.getState());
		try {
			t2.join();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("State pf t2 after completion "+t2.getState());
		System.out.println("State pf t1 after completion "+t1.getState());
	}

}
