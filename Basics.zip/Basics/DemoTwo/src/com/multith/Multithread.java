package com.multith;

import java.util.Iterator;

public class Multithread {

	public static void main(String[] args) {
//		int n=10;
//		
//		for(int i=0;i<n;i++) {
//			MultithreadingDemo demo = new MultithreadingDemo();
//			demo.start();
//		}
		
		MultithreadingDemo demo1 = new MultithreadingDemo();
		MultithreadingDemo demo2 = new MultithreadingDemo();
		demo1.start();
		demo2.start();
	}
}
