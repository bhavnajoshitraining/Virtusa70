package com.multith;

public class MultithreadingDemo extends Thread {
	public void run() {
//		try {
//			System.out.println( "Thread:- "+ Thread.currentThread().getId()+" is running");
//		} catch (Exception e) {
//			System.out.println("Exception occured!!");
//		}
		
		for(int i=1;i<5;i++) {
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
			}
			
			System.out.println(i);
		}
	} 
}
