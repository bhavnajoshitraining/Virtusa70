package com.poly;

public class Animal {
	int age=10;
	public void sound() {
		System.out.println("Animal is making sound!!");
	}
	
	public void sound(int i) {
		System.out.println("i is making sound!!"+i);
	}
	
	public void sound(char c) {
		System.out.println("c is making sound!!"+c);
	}
	
	public void sound(int a, int b) {
		System.out.println("a,b is making sound!!"+a+b);
	}
}
