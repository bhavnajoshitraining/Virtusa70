package com.poly;

public class Demo{
	public static void main(String[] args) {
		Animal chetak = new Horse();
		chetak.sound(1,2);
	}
}
