package com.poly;

public class Horse extends Animal {
	
	}
