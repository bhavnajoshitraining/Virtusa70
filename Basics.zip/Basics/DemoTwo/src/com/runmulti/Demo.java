package com.runmulti;

public class Demo {

	public static void main(String[] args) {
		int n=5;
		for(int i =0;i<n;i++) {
			Thread objThread = new Thread(new Mult());
			objThread.start();
		}

	}

}
