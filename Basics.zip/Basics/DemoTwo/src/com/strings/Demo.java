package com.strings;

public class Demo {

	public static void main(String[] args) {
		//Create String
		
		String name = "bhavna";
		String fame = "bhavna Joshi1113333is87896 a tech4444 trainer";
		String surname = "Joshi";
		String address="Bangalore";
		String newString = new String("guddu");
		
		System.out.println("First String:- "+name);
		System.out.println("Second String:- "+surname);
		
//		boolean result = fame.contains(name);
//		boolean result = fame.contains(surname);
//		System.out.println(result);
		
//		
//		System.out.println(name.substring(2,5));
//		
//		System.out.println(name.charAt(2));
		
//		String joinDemo = String.join(" ", name,fame,surname,address);
//		System.out.println(joinDemo);
		
//		String regex = "\\s";
//		//System.out.println(fame.replace("avn", "nnn"));
//		System.out.println(fame.replaceAll(regex, "@"));
		
//		String regex ="\\d+";
//		
//		System.out.println(fame.replaceFirst(regex, "num"));	
		
		//print array
		
//		System.out.println(name);
//		System.out.println(address);
		
		//string operations
		
		//length
		//int length = name.length();
		//System.out.println("length of name is:- "+length);
		
		//concat
		
//		String fullname = name.concat(surname);
//		
//		System.out.println(fullname);
//		
//		//compare
//		
//		boolean result1 = name.equals(fame);
//		
//		System.out.println(result1);

//		int result2 = name.compareTo(surname);
//		System.out.println(result2);
//		if(result2==1) {
//			System.out.println("its 1 and both the strings are not equal");
//		} else if(result2==0){
//			System.out.println("its 0 and both the strings are equal");
//		}else if(result2>0) {
//			System.out.println("its 1 and both the strings are not equal and one is greater");
//		}	else if(result2<0) {
//			System.out.println("its 1 and both the strings are not equal and one is greater");
//		}
		
	}

}
