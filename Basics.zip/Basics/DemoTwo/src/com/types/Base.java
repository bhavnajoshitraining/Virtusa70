package com.types;

public class Base {

	int a;
	String b;
	
	public int sum(int b1,int b2) {
		return b1+b2;
	}
}
