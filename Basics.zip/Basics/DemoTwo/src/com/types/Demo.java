package com.types;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//single level example
//		Single obj = new Single();
//		obj.a=1;
//		obj.b="shanu";
//		obj.display();
		
		//Multilevel example
//		Test t = new Test();
		//t.dance();
//		int s= t.sum(2, 2);
//		System.out.println(s);
		
	}

}
