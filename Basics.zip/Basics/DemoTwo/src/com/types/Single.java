package com.types;

public class Single extends Base{

	public void display() {
		int sums = sum(1,2);
		System.out.println(sums);
		System.out.println("value of a is :- "+a);
		System.out.println("value of b is :- "+b);
	}
}
