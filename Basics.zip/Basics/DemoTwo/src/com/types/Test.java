package com.types;

public class Test extends Single {

	public void dance() {
		System.out.println("i am from dance of Test class");
		int a = sum(5,5);
		System.out.println("a is "+a);
	}
}
